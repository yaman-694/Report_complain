const express = require('express')
const app = express();
const bodyParser = require('body-parser')
const cookieParser = require('cookie-parser')
const input = require('./routes/input')
const config = require('./config/mongoDB')
const mongoose = require('mongoose')
const xlsx = require('xlsx');
const Report = require('./model/input')


mongoose.set('strictQuery', false);

//connect to mongoDB
mongoose.connect(config.mongo.mongoUrl, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('MongoDB Connected'))
    .catch(err => console.log(err));



//Set View engine
app.set("view engine", "ejs");

//set public folder static
app.use(express.static('public'));

//set middleware
// app.use(bodyParser)
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json())
app.use(cookieParser())
require("dotenv").config();

//set routes
app.use('/api/v1',input);
app.get('/download',(req,res)=>{
    var wb = xlsx.utils.book_new();
    Report.find((err,data)=>{
        if(err){
            console.log(err);
        }
        else{
            var temp = JSON.stringify(data);
            temp = JSON.parse(temp);
            
            for(var i = 0;i<temp.length;i++)
            {
            temp[i]._id=i+1;
            delete temp[i].__v;
        }
            console.log(temp)
            var ws = xlsx.utils.json_to_sheet(temp);
            var down = __dirname + '/public/export.xlsx'
            xlsx.utils.book_append_sheet(wb,ws,"Sheet1");
            // console.log(ws);
            xlsx.writeFile(wb,down);
            res.download(down);
        }
    })

})

app.listen(3000, () => {
    console.log('Example app listening on port 3000!')
    });