const config = {
    "port": 3000,
    mongo:{
        "mongoUrl": "mongodb://localhost:27017/new",
    }
}

module.exports = config;