const express = require('express');
const router = express.Router();
const input = require('../controller/input')

router.post('/input',input);

module.exports = router;

